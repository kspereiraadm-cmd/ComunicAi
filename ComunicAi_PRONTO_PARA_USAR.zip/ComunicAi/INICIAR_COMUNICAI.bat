@echo off
setlocal
cd /d "%~dp0"
title ComunicAí - Sistema de Comunicação Interna

echo.
echo ============================================
echo              COMUNICAI
echo        Comunicacao Interna
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 goto NONODE

if not exist node_modules (
  echo Primeira vez: instalando os componentes...
  echo Isso pode levar alguns minutos.
  call npm install
  if errorlevel 1 goto NPMERROR
)

echo Iniciando o ComunicAi...
start "" http://localhost:3000
node server.js
goto END

:NONODE
echo.
echo O computador ainda nao tem o Node.js instalado.
echo.
echo Instale o Node.js LTS pelo site oficial:
echo https://nodejs.org/
echo.
pause
goto END

:NPMERROR
echo.
echo Nao foi possivel instalar os componentes.
echo Verifique sua internet e tente novamente.
pause

:END
endlocal
