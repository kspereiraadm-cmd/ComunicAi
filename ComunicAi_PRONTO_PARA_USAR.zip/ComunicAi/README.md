# ComunicAí — v0.4

Sistema interno de comunicação da clínica, desenvolvido por Karoline Sampaio.

## O que mudou no v0.4
- Central de Administração com PIN.
- Cadastro persistente de locais/consultórios e responsável.
- Cadastro persistente de recados rápidos.
- Alterações de configuração são enviadas em tempo real para as telas abertas.
- Cada destinatário tem seu próprio status de recebimento.
- Se um recado for enviado para vários locais, a recepção consegue ver quem já recebeu e quem ainda aguarda.
- Tela do consultório recebe somente os recados destinados àquele local.
- Botão **Ativar som** para contornar bloqueios de áudio dos navegadores.

## Como usar
1. Instale o Node.js.
2. Abra o terminal nesta pasta.
3. Rode `npm install`.
4. Rode `npm start`.
5. No computador da recepção, abra `http://localhost:3000`.
6. Nos computadores dos consultórios, abra `http://IP-DO-COMPUTADOR-DA-RECEPÇÃO:3000/?room=consultorio-1` (troque o ID conforme o local).
7. Na primeira vez em cada consultório, clique em **Ativar som**.

## Administração
Clique em **⚙️ Administração** e use o PIN inicial `1234`.

O PIN pode ser alterado diretamente em `config.json`, no campo `adminPin`.

## Observação
O projeto é pensado para uso na rede interna da clínica. O PIN é uma proteção simples de administração, não um sistema de segurança empresarial.
