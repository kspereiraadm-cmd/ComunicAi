const fs = require("fs");
const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const CONFIG_FILE = path.join(ROOT, "config.json");
const DATA_FILE = path.join(ROOT, "data", "messages.json");

function loadConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8")); }
  catch { return { rooms: [], quickMessages: [], adminPin: "1234" }; }
}
function saveConfig(config) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf8");
}
function loadMessages() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function saveMessages(messages) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(messages.slice(0, 300), null, 2), "utf8");
}
function now() {
  const d = new Date();
  return d.toLocaleString("pt-BR", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" });
}
function publicConfig() {
  const c = loadConfig();
  return { rooms: c.rooms || [], quickMessages: c.quickMessages || [] };
}
function normalizeRoomIds(config, recipients) {
  const valid = new Set((config.rooms || []).map(r => r.id));
  return [...new Set((recipients || []).filter(id => valid.has(id)))];
}

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(ROOT, "public")));

app.get("/api/config", (_, res) => res.json(publicConfig()));
app.get("/api/messages", (_, res) => res.json(loadMessages().slice(0, 100)));

app.post("/api/admin/auth", (req, res) => {
  const config = loadConfig();
  const pin = String(req.body?.pin || "");
  if (pin && pin === String(config.adminPin || "1234")) return res.json({ ok: true });
  return res.status(401).json({ ok: false, error: "PIN inválido." });
});

app.put("/api/config", (req, res) => {
  const body = req.body || {};
  if (!Array.isArray(body.rooms) || !Array.isArray(body.quickMessages)) {
    return res.status(400).json({ ok: false, error: "Configuração inválida." });
  }
  const rooms = body.rooms
    .map(r => ({ id: String(r.id || "").trim(), name: String(r.name || "").trim(), person: String(r.person || "").trim(), type: String(r.type || "Consultório").trim() }))
    .filter(r => r.id && r.name);
  const ids = new Set();
  for (const r of rooms) {
    if (ids.has(r.id)) return res.status(400).json({ ok: false, error: "Há locais com identificadores repetidos." });
    ids.add(r.id);
  }
  const quickMessages = body.quickMessages
    .map(q => ({ icon: String(q.icon || "💬"), label: String(q.label || "").trim(), text: String(q.text || "").trim() }))
    .filter(q => q.label && q.text);

  const config = loadConfig();
  config.rooms = rooms;
  config.quickMessages = quickMessages;
  saveConfig(config);

  io.emit("configUpdated", publicConfig());
  res.json({ ok: true, config: publicConfig() });
});

io.on("connection", (socket) => {
  socket.on("register", ({ mode, roomId }) => {
    socket.data.mode = mode;
    socket.data.roomId = roomId;
    if (mode === "room" && roomId) socket.join(`room:${roomId}`);
    socket.emit("config", publicConfig());
    socket.emit("history", loadMessages().slice(0, 100));
  });

  socket.on("changeRoom", ({ roomId }) => {
    const previous = socket.data.roomId;
    if (previous) socket.leave(`room:${previous}`);
    socket.data.roomId = roomId;
    if (roomId) socket.join(`room:${roomId}`);
  });

  socket.on("sendMessage", ({ recipients, text, quickLabel }) => {
    const config = loadConfig();
    let cleanRecipients = normalizeRoomIds(config, recipients);
    if (!cleanRecipients.length || !String(text || "").trim()) return;

    const recipientState = {};
    cleanRecipients.forEach(id => { recipientState[id] = { acknowledged: false, acknowledgedAt: null }; });

    const msg = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      time: now(),
      recipients: cleanRecipients,
      recipientState,
      text: String(text).trim(),
      quickLabel: quickLabel || "",
      status: "pending"
    };
    const messages = loadMessages();
    messages.unshift(msg);
    saveMessages(messages);

    for (const recipient of cleanRecipients) io.to(`room:${recipient}`).emit("newMessage", msg);
    io.emit("messageCreated", msg);
  });

  socket.on("acknowledge", ({ messageId, roomId }) => {
    if (!roomId) return;
    const messages = loadMessages();
    const m = messages.find(x => x.id === messageId);
    if (!m || !m.recipients.includes(roomId)) return;
    m.recipientState = m.recipientState || {};
    m.recipientState[roomId] = { acknowledged: true, acknowledgedAt: now() };
    const allAck = m.recipients.every(id => m.recipientState[id]?.acknowledged);
    m.status = allAck ? "received" : "partial";
    saveMessages(messages);
    io.emit("messageUpdated", m);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`ComunicAí rodando em http://localhost:${PORT}`);
});
